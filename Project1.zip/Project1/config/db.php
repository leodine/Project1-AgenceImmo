<?php

/**
 * This file define BD access infos.
 *
 * PHP version 7
 *
 * @category  PHP
 * @package   PHP_SimpleMVC
 * @author    WCS <contact@wildcodeschool.fr>
 * @license  --
 * @link     https://github.com/WildCodeSchool/simple-mvc
 *
 */

define('APP_DB_HOST', 'localhost');
define('APP_DB_NAME', 'dbAgenceImmo');
define('APP_DB_USER', 'leodine');
define('APP_DB_PWD', 'Leodin7&');


