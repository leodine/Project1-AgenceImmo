<?php
/**
 * PHP version 7
 */

namespace App\Model;

/**
 *
 */
 
class HomeManager extends AbstractManager
{
    /**
     *
     */
    const TABLE = 'item';

    /**
     *  Initializes this class.
     */
    public function __construct()
    {
        parent::__construct(self::TABLE);
    }
}
